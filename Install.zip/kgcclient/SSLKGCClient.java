package kgcclient;

import java.io.*;
import java.util.Properties;
import javax.net.ssl.*;
/**
 * @author Isabelle Tingzon
 * @author Angelu Kaye Tiu
 */
public class SSLKGCClient{
    
    private final String HOST;
    private final String PUBKEY;
    private final String PWD;
    private final int PORT;
    
    private String USERID;
    private String ATTR;
    
    private DataInputStream  console   = null;
    private DataOutputStream streamOut = null;
    private DataInputStream streamIn =  null;
    private SSLSocketFactory factory;
    
    public SSLKGCClient(){
        		

        HOST = "localhost";
        PORT = 8443;
        PUBKEY = "/Users/angelukayetiu/Desktop/ehr-abe-tingzon-tiu/WebContent/resources/SSLkeys/public.jks";
        PWD = "password";
        System.out.println(HOST+PORT+PUBKEY+PWD);
        System.out.println("set up kgc client");
    }
    
    //TODO find a way to send multiple files without having to close/open multiple client sockets.         
    public void fetchKeys(String userid, String attributes){
        USERID = userid;
        ATTR = attributes; 
        System.out.println("attributes "+attributes);
        System.out.println("attributes "+attributes.replaceAll("\"", ""));        
        try {
            System.out.println("init ssl prop");
            //Initialize SSL Properties
            System.setProperty("javax.net.ssl.trustStore", PUBKEY);
            System.setProperty("javax.net.ssl.keyStorePassword", PWD);
            factory = (SSLSocketFactory) SSLSocketFactory.getDefault();

            
            System.out.println("init socket masterkey");
            //MASTER_KEY
            SSLSocket socket = (SSLSocket) factory.createSocket(HOST, PORT);
            System.out.println("init");
            socket.startHandshake();
            System.out.println("isgsy");
            streamOut = new DataOutputStream(socket.getOutputStream());
            System.out.println("inasdfey");
            streamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));            
            System.out.println("inisdferkey");
            
            //Client sends message "master_key"
            System.out.println("masterkey");
            String writeLine = "master_key";
            streamOut.writeUTF(writeLine);
            streamOut.flush();
        
            System.out.println("get mk");
            //Client reads mk filesize
            String filesize = streamIn.readUTF();
            
            //Client recieves master_key and closes socket
            getFile(socket, writeLine, Integer.parseInt(filesize));
            socket.close();
            System.out.println("recieved mk");
            
            //PUBLIC_KEY
            socket = (SSLSocket) factory.createSocket(HOST, PORT);
            socket.startHandshake();
            streamOut = new DataOutputStream(socket.getOutputStream());
            streamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            
            //Client sends message "public_key"
            writeLine = "pub_key";
            streamOut.writeUTF(writeLine);
            streamOut.flush();
            
            //Client reads pk filesize
            filesize = streamIn.readUTF();
        
            //Client recieves public_key and closes socket
            getFile(socket, writeLine, Integer.parseInt(filesize));
            socket.close();
            
            //ATTRIBUTES/SECRET_KEY
            socket = (SSLSocket) factory.createSocket(HOST, PORT);
            socket.startHandshake();
            streamOut = new DataOutputStream(socket.getOutputStream());
            streamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        
            //Client sends message "secret_key", requesting for the secret key
            writeLine = "secret_key";
            streamOut.writeUTF(writeLine);
            streamOut.flush();
        
            //Client send Username
            writeLine = USERID;
            streamOut.writeUTF(writeLine);
            streamOut.flush();
            
            //Client sends Attributes
            writeLine = ATTR;
            streamOut.writeUTF(writeLine);
            streamOut.flush();
            
            //Client reads pk filesize
            filesize = streamIn.readUTF();
            
            getFile(socket, USERID, Integer.parseInt(filesize));
            socket.close();
            
            //Client sends message indicating to delete the key
            socket = (SSLSocket) factory.createSocket(HOST, PORT);
            socket.startHandshake();
            streamOut = new DataOutputStream(socket.getOutputStream());
            streamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        
            writeLine = "remove";
            streamOut.writeUTF(writeLine);
            streamOut.flush();
            
            writeLine = USERID;
            streamOut.writeUTF(writeLine);
            streamOut.flush();
            
            socket.close();
            System.out.println("closed socked");

        } catch (IOException e){
        		e.printStackTrace();
            System.out.println("io exception");

         } catch( NumberFormatException e) {
        	 	e.printStackTrace();
             System.out.println("number format exception");
         }
    }
   
    private void getFile(SSLSocket socket, String get_filename, int fileSize) throws IOException{
        BufferedInputStream get = new BufferedInputStream(socket.getInputStream());
        PrintWriter put = new PrintWriter(socket.getOutputStream(),true);
        
        // receive file
        byte [] mybytearray  = new byte [fileSize];
        InputStream is = socket.getInputStream();
        FileOutputStream fos = new FileOutputStream(get_filename);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        int bytesRead = is.read(mybytearray,0,mybytearray.length);
        int current = bytesRead;

        do {
           bytesRead = is.read(mybytearray, current, (mybytearray.length-current));
           if(bytesRead >= 0) current += bytesRead;
        } while(current < fileSize);

        bos.write(mybytearray, 0 , current);
        bos.flush();
        System.out.println("File " + get_filename
            + " downloaded (" + current + " bytes read)");
    } 


    public static void main(String args[]){
        System.out.println("generate keys");        
        SSLKGCClient client;
            client = new SSLKGCClient();
            System.out.println("new kgc");
            client.fetchKeys(args[0], args[1]);
            System.out.println("fetched");
            System.out.println("generation error");
        System.out.println("Generate done");
            
    }
}
